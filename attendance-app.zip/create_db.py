import sqlite3

conn = sqlite3.connect('attendance.db')
c = conn.cursor()

c.execute('''
CREATE TABLE students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    father_name TEXT NOT NULL
)
''')

c.execute('''
CREATE TABLE attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    status TEXT,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

c.execute("INSERT INTO students (name, father_name) VALUES ('Ali', 'Ahmed')")
c.execute("INSERT INTO students (name, father_name) VALUES ('Fatima', 'Rashid')")

conn.commit()
conn.close()